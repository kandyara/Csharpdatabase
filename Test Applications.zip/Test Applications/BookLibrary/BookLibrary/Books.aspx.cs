﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace BookLibrary
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (GridView1.SelectedRow != null)
            {
                Server.Transfer("~/BooksDetails.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alert",
                    "alert('Please select a row.')", true);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Server.Transfer("~/BooksDetails.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;

            connetionString = @"Data Source=LAPTOP-PHRBSSI3\SQLEXPRESS;Initial Catalog=BOOKSDB;Integrated Security=True";
            cnn = new SqlConnection(connetionString);
            GridViewRow selectedRow = GridView1.SelectedRow;
            var Label = gvrow.FindControl("Label1") as Label;

            SqlCommand cmd = new SqlCommand("delete from TBooks where ISBN=@ISBN", con);
            cmd.Parameters.AddWithValue("ISBN", int.Parse(Label.Text));
            con.Open();
            int id = cmd.ExecuteNonQuery();
            con.Close();
            refreshdata();   
        }

            
    }
}
