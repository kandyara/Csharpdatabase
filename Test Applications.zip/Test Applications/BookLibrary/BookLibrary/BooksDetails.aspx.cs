﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace BookLibrary
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string connetionString;
            SqlConnection cnn;

            connetionString = @"Data Source=LAPTOP-PHRBSSI3\SQLEXPRESS;Initial Catalog=BOOKSDB;Integrated Security=True";
            cnn = new SqlConnection(connetionString);
            SqlCommand command;
		SqlDataAdapter adapter = new SqlDataAdapter(); 
		String sql="";

           sql = "Insert into TBooks(ISBN,Title,Author,PublishDate,Price,Publish) value("'Text1.Text'", "'Text2.Text'","'Text3.Text'","'Text4.Text'","'Text5.Text'", "'Text1.Text'")";
		
		command = new SqlCommand(sql,cnn);
		adapter.InsertCommand = new SqlCommand(sql,cnn); 
		adapter.InsertCommand.ExecuteNonQuery();

		command.Dispose(); 
		cnn.Close();
        }
    }
}
